const css = "./styles/main.css"; // css url (just make sure the directory is set ok, powertik.js will make the file itself)
const index = "./index.html"; // index url or the file to watch url

module.exports = {
  cssURL: css,
  indexURL: index,
};

exports.cssURL = css;
exports.indexURL = index;
