let classes = new Array(); // every elements classes
let elementsWithClass = new Array(); // every element that has a class
let hoverElements = new Array(); // every element that has a hover: class

const fs = require("fs"); // Import the fs module
const { log } = require("util");
const { indexURL, cssURL } = require("./powertik-files");
fs.readFile(indexURL, "utf8", (err, data) => {
  // Read the file index.html
  if (err) {
    console.error(err); // Handle errors
  } else {
    let css = new Array(); // everything that is going to the css file:

    // css predefined shortcuts
    let full_class_shortcuts = [
      ["flex", "display", "flex"],
      ["block", "display", "block"],
      ["grid", "display", "grid"],
      ["inline-block", "display", "inline-block"],
      ["justify-center", "justify-content", "center"],
      ["justify-even", "justify-content", "space-evenly"],
      ["justify-between", "justify-content", "space-between"],
      ["justify-around", "justify-content", "space-around"],
      ["justify-start", "justify-content", "flex-start"],
      ["justify-end", "justify-content", "flex-end"],
      ["align-center", "align-items", "center"],
      ["align-start", "align-items", "flex-start"],
      ["align-end", "align-items", "flex-end"],
      ["align-stretch", "align-items", "stretch"],
      ["mx-auto", "margin", "auto", "horizontal"],
      ["my-auto", "margin", "auto", "vertical"],
      ["px-auto", "padding", "auto", "horizontal"],
      ["py-auto", "padding", "auto", "vertical"],
      ["ms-auto", "margin-left", "auto"],
      ["me-auto", "margin-right", "auto"],
      ["ps-auto", "padding-left", "auto"],
      ["pe-auto", "padding-right", "auto"],
      ["flex-col", "flex-direction", "column"],
      ["col-reverse", "flex-direction", "column-reverse"],
      ["flex-row", "flex-direction", "row"],
      ["row-reverse", "flex-direction", "row-reverse"],
      ["wrap", "flex-wrap", "wrap"],
      ["wrap-reverse", "flex-wrap", "wrap-reverse"],
      ["nowrap", "flex-wrap", "nowrap"],
      ["pointer", "cursor", "pointer"],
      ["decoration-none", "text-decoration", "none"],
      ["decimal", "list-style", "decimal"],
      ["disc", "list-style", "disc"],
      ["lower-roman", "list-style", "lower-roman"],
      ["upper-roman", "list-style", "upper-roman"],
      ["font-thin", "font-weight", "100"],
      ["font-lighter", "font-weight", "200"],
      ["font-light", "font-weight", "300"],
      ["font-normal", "font-weight", "400"],
      ["font-medium", "font-weight", "500"],
      ["font-semi-bold", "font-weight", "600"],
      ["font-bold", "font-weight", "700"],
      ["font-bolder", "font-weight", "800"],
      ["font-black", "font-weight", "900"],
      ["w-max", "width", "max-content"],
      ["w-min", "width", "min-content"],
      ["w-auto", "width", "auto"],
      ["h-auto", "height", "auto"],
      ["h-max", "height", "max-content"],
      ["h-min", "height", "min-content"],
      ["radius-100", "border-radius", "100%"],
      ["radius-50", "border-radius", "50%"],
      ["circle", "border-radius", "99999px"],
      ["color-inherit", "color", "inherit"],
      ["text-white", "color", "white"],
      ["text-black", "color", "black"],
      ["text-center", "text-align", "center"],
      ["transition-linear", "transition-timing-function", "linear"],
      ["transition-ease", "transition-timing-function", "ease"],
      ["transition-ease-in", "transition-timing-function", "ease-in"],
      ["transition-ease-out", "transition-timing-function", "ease-out"],
      ["transition-ease-in-out", "transition-timing-function", "ease-in-out"],
      ["transition-100", "transition-duration", "100ms"],
      ["transition-150", "transition-duration", "150ms"],
      ["transition-200", "transition-duration", "200ms"],
      ["transition-250", "transition-duration", "250ms"],
      ["transition-300", "transition-duration", "300ms"],
      ["transition-350", "transition-duration", "350ms"],
      ["transition-400", "transition-duration", "400ms"],
      ["transition-450", "transition-duration", "450ms"],
      ["transition-500", "transition-duration", "500ms"],
      ["transition-600", "transition-duration", "600ms"],
      ["transition-700", "transition-duration", "700ms"],
      ["transition-800", "transition-duration", "80ms"],
      ["transition-900", "transition-duration", "900ms"],
      ["transition-1000", "transition-duration", "1s"],
      ["transition-2000", "transition-duration", "2s"],
      ["transition-5000", "transition-duration", "5s"],
      ["transition-all", "transition-property", "all"],
      ["transition-none", "transition-property", "none"],
      ["transform-top", "transform-origin", "top"],
      ["transform-right", "transform-origin", "right"],
      ["transform-bottom", "transform-origin", "bottom"],
      ["transform-left", "transform-origin", "left"],
      ["transform-center", "transform-origin", "center"],
      ["border-none", "border", "none"],
      ["border-unset", "border", "unset"],
      ["outline-none", "outline", "none"],
      ["outline-unset", "outline", "unset"],
      ["bg-black", "background-color", "black"],
      ["bg-white", "background-color", "white"],
      ["decoration-underline", "text-decoration", "underline"],
      ["text-left", "text-align", "left"],
      ["text-right", "text-align", "right"],
    ];

    // css shortcuts for html classes
    let css_shortcuts = [
      ["p", "padding"],
      ["pt", "padding-top"],
      ["pr", "padding-right"],
      ["pb", "padding-bottom"],
      ["pl", "padding-left"],
      ["px", "padding", "horizontal"],
      ["py", "padding", "vertical"],
      ["m", "margin"],
      ["mt", "margin-top"],
      ["mr", "margin-right"],
      ["mb", "margin-bottom"],
      ["ml", "margin-left"],
      ["mx", "margin", "horizontal"],
      ["my", "margin", "vertical"],
      ["w", "width"],
      ["h", "height"],
      ["radius", "border-radius"],
      ["radius-tl", "border-top-left-radius"],
      ["radius-tr", "border-top-right-radius"],
      ["radius-bl", "border-bottom-left-radius"],
      ["radius-br", "border-bottom-right-radius"],
      ["border", "border"],
      ["b-style", "border-style"],
      ["b-width", "border-width"],
      ["b-color", "border-color"],
      ["outline", "outline"],
      ["outline-offest", "outline-offest"],
      ["outline-color", "outline-color"],
      ["outline-style", "outline-style"],
      ["outline-width", "outline-width"],
      ["box", "box-sizing"],
      ["d", "display"],
      ["align", "align-items"],
      ["justify", "justify-content"],
      ["right", "right"],
      ["top", "top"],
      ["bottom", "bottom"],
      ["left", "left"],
      ["z", "z-index"],
      ["cursor", "cursor"],
      ["transition", "transition"],
      ["pos", "position"],
      ["bg", "background"],
      ["bg-color", "background-color"],
      ["shadow", "box-shadow"],
      ["transform", "transform"],
      ["fos", "font-size"],
      ["line", "line-height"],
      ["color", "color"],
      ["opacity", "opacity"],
      ["fof", "font-family"],
      ["border-b", "border-bottom"],
      ["border-t", "border-top"],
      ["border-l", "border-left"],
      ["border-r", "border-right"],
      ["bt-style", "border-top-style"],
      ["bt-width", "border-top-width"],
      ["bt-color", "border-top-color"],
      ["bb-style", "border-bottom-style"],
      ["bb-width", "border-bottom-width"],
      ["bb-color", "border-bottom-color"],
      ["bl-style", "border-left-style"],
      ["bl-width", "border-left-width"],
      ["bl-color", "border-left-color"],
      ["br-style", "border-right-style"],
      ["br-width", "border-right-width"],
      ["br-color", "border-right-color"],
      ["text", "text-align"],
      ["decoration", "text-decoration"],
      ["gap", "gap"],
      ["grow", "flex-grow"],
      ["style", "list-style"],
      ["overflow", "overflow"],
      ["filter", "filter"],
      ["backdrop", "backdrop-filter"],
      ["bg-image", "background-image"],
      ["bg-size", "background-size"],
      ["bg-pos", "background-position"],
      ["bg-posy", "background-position-y"],
      ["bg-posx", "background-position-x"],
      ["bg-clip", "background-clip"],
      ["bg-blend", "background-blend-mode"],
      ["bg-attach", "background-attachment"],
      ["bg-rep", "background-repeat"],
      ["mix", "mix-blend-mode"],
      ["dir", "direction"],
      ["basis", "flex-basis"],
      ["shrink", "flex-shrink"],
      ["flex", "flex"],
      ["flex-dir", "flex-direction"],
      ["cols", "columns"],
      ["col-gap", "column-gap"],
      ["row-gap", "row-gap"],
      ["grid-row", "grid-template-rows"],
      ["grid-col", "grid-template-columns"],
      ["grid-area", "grid-template-area"],
      ["auto-col", "grid-template-cloumns"],
      ["auto-row", "grid-template-rows"],
      ["area", "grid-area"],
      ["max-w", "max-width"],
      ["min-w", "min-width"],
      ["max-h", "max-height"],
      ["min-h", "min-height"],
      ["transition-property", "transition-property"],
      ["transition-duration", "transition-duration"],
      ["transition-timing", "transition-timing-function"],
      ["transform-origin", "transform-origin"],
    ];

    // classes that don't get pixels:
    let css_excludes = [
      "d",
      "box",
      "align",
      "justify",
      "z",
      "cursor",
      "bg",
      "bg-color",
      "shadow",
      "transform",
      "color",
      "opacity",
      "fof",
      "border-b",
      "border-t",
      "border-l",
      "border-r",
      "bt-style",
      "bl-style",
      "br-style",
      "bb-style",
      "bt-color",
      "br-color",
      "bb-color",
      "bl-color",
      "text",
      "decoration",
      "overflow",
      "filter",
      "backdrop",
      "mix",
      "dir",
      "basis",
      "shrink",
      "flex",
      "flex-dir",
      "cols",
      "grid-row",
      "grid-col",
      "grid-area",
      "auto-col",
      "auto-row",
      "area",
      "transition-property",
      "transition-duration",
      "transition-timing",
      "transform-origin",
      "transition",
    ];

    // adding variables to css:
    css.push(`:root {
  --combination0-0: #685884;
  --combination0-1: #9c8ab9;
  --combination0-2: #f9eaff;
  --combination0-3: #00c9a4;
  --gradient-combination0: linear-gradient(to left bottom, #685884, #72618e, #7b6a97, #8574a1, #8f7dab, #9b89b5, #a895c0, #b4a1ca, #c6b3d7, #d7c5e4, #e8d7f1, #f9eaff);
  --combination1-0: #615F64;
  --combination1-1: #685884;
  --combination1-2: #563296;
  --gradient-combination1: linear-gradient(to left bottom, #615f64, #635e6a, #645d70, #665b76, #675a7c, #665680, #655385, #644f89, #61488c, #5d4190, #5a3a93, #563296);
  --red-00: #FF0000;
  --red-200: #DB0000;
  --red-400: #B80000;
  --red-600: #960000;
  --red-800: #760000;
  --orange-00: #FF8500;
  --orange-200: #D36100;
  --orange-400: #A83F00;
  --orange-600: #801A00;
  --orange-800: #5D0000;
  --yellow-00: #FFFF00;
  --yellow-200: #C3C800;
  --yellow-400: #899400;
  --yellow-600: #556300;
  --yellow-800: #333500;
  --lightgreen-00: #9BFF00;
  --lightgreen-200: #62CB00;
  --lightgreen-400: #1D9800;
  --lightgreen-600: #006800;
  --lightgreen-800: #003A00;
  --green-00: #00FF00;
  --green-200: #00CB00;
  --green-400: #009A00;
  --green-600: #006900;
  --green-800: #003D00;
  --cyan-00: #00FFFF;
  --cyan-200: #00CACB;
  --cyan-400: #00989A;
  --cyan-600: #00686B;
  --cyan-800: #003B40;
  --lightblue-00: #009BFF;
  --lightblue-200: #007BDB;
  --lightblue-400: #005DB8;
  --lightblue-600: #004196;
  --lightblue-800: #002775;
  --blue-00: #0000FF;
  --blue-200: #0000CC;
  --blue-400: #000099;
  --blue-600: #000066;
  --blue-800: #00005E;
  --purple-800: #3E0066;
  --purple-600: #6B2F92;
  --purple-400: #985AC0;
  --purple-200: #C886F0;
  --purple-00: #F9B4FF;
  --pink-00: #FF00BC;
  --pink-200: #DB009D;
  --pink-400: #B8007F;
  --pink-600: #960062;
  --pink-800: #730047;
  --rose-00: #FF0037;
  --rose-200: #DB0020;
  --rose-400: #B80009;
  --rose-600: #950000;
  --rose-800: #750000;
}

*{
  padding: 0;
  margin: 0;
  box-sizing: border-box;
  font-family: sans-serif;
}
\n`);

    // getting the body tag
    let full_document = data.slice(
      data.indexOf("<body>") + 6,
      data.indexOf("</body>")
    );

    let element_classes = full_document;

    function getElementsWithClass() {
      let temp_class;
      if (element_classes.includes("<")) {
        temp_class = element_classes.slice(
          element_classes.indexOf("<"),
          element_classes.indexOf(">") + 1
        );
        console.log(temp_class.indexOf("class"));
        if (temp_class.includes("calss")) {
          console.log(temp_class);
          elementsWithClass.push(temp_class);
          if (temp_class.includes("hover:")) {
            hoverElements.push(temp_class);
          }
        }
        element_classes = element_classes.slice(
          element_classes.indexOf(">") + 1,
          element_classes.length - 1
        );
        getElementsWithClass();
      } else {
        element_classes = full_document;
      }
    }
    // getElementsWithClass();

    let document_classes = full_document; // gettinh a copy of full_document

    // getting every class of an element
    function getClasses() {
      if (document_classes.includes(`class="`)) {
        document_classes = document_classes.slice(
          document_classes.indexOf(`class="`) + 7,
          document_classes.length - 1
        );
        classes.push(document_classes.slice(0, document_classes.indexOf(`"`)));
        getClasses();
      } else {
        document_classes = full_document;
      }
    }
    getClasses();

    let class_property = new Array(); // every existing class
    classes.forEach((elem) => {
      let elem_classes = elem.split(" ");
      elem_classes.forEach((element) => class_property.push(element));
    });

    class_property = [...new Set(class_property)]; // removing repeated classes

    // seperating classes that contain "-" or "-[]"
    let customClassses = new Array(); // evry class in form of x-[y]
    let preDefinedClasses = new Array(); // every class in form of abcd
    let autoClasses = new Array(); // every clas in form of x-0
    let pro_classes = {
      raw: ["dark:", "hover:"],
      developed: ["pt-dark-", "hover:"],
    };

    function seperateClasses() {
      for (i in class_property) {
        let autoReg = /[a-zA-Z]+-\d+/g; // regEx for autoClass
        let customReg = /[a-zA-Z]+-\[/g; // regEx for autoClass

        if (customReg.test(class_property[i])) {
          customClassses.push(class_property[i]); // filtering custom classe
          checkProClasses(i, customClassses); // checking for possible pro classes
        } else if (autoReg.test(class_property[i])) {
          autoClasses.push(class_property[i]); // filtering auto classes
          checkProClasses(i, autoClasses); // checking for possible pro classes
        } else {
          preDefinedClasses.push(class_property[i]); // filtering pre defined classes}
          checkProClasses(i, preDefinedClasses); // checking for possible pro classes
        }
      }
    }
    seperateClasses(); // envoking the seperateClasses function

    function checkProClasses(index, checkingArray) {
      let permission = true; // permission for getting only the non-repeated classes
      pro_classes.raw.forEach((elem, k) => {
        if (class_property[index].includes(elem)) {
          // selecting $keyword classes

          let temp_class = class_property[index].replace(
            elem,
            pro_classes.developed[k]
          );

          checkingArray.pop();
          checkingArray.push(temp_class);
        }
      });
    }

    let full_property = { allClasses: new Array() }; // every auto and custom class
    let pro_classes_index = {
      custom_auto_classes: new Array(),
      preDefinedClasses: new Array(),
    };

    // puring every auto and custom class inside full_property.allClasses and defining the types (useful for css print)
    function propertyValues() {
      for (i in autoClasses) {
        autoClasses[i] = [
          autoClasses[i].slice(0, autoClasses[i].lastIndexOf("-")),
          autoClasses[i].slice(
            autoClasses[i].lastIndexOf("-") + 1,
            autoClasses[i].length
          ),
        ];
        autoClasses[i].push("autoClass"); // defining the auto class types
        full_property.allClasses.push(autoClasses[i]);
      }
      for (i in customClassses) {
        let temp_class = customClassses[i].slice(
          0,
          customClassses[i].indexOf("]")
        );
        full_property.allClasses.push(temp_class.split("-["));
        full_property.allClasses[full_property.allClasses.length - 1].push(
          "customClass" // defining the custom class types
        );
      }
    }
    propertyValues(); // envoking the propertyValues function

    let property_name; // css property names
    let auto_size; // auto class property values
    let xy_situation = "none"; // vertical (py) or horizontal (mx) or none (w)

    // simplifying every html class for css_base function
    function convertingClasses() {
      for (i in full_property.allClasses) {
        // moving classes to preDefined classes
        for (j in full_class_shortcuts) {
          if (
            full_property.allClasses[i][0] +
              "-" +
              full_property.allClasses[i][1] ==
            full_class_shortcuts[j][0]
          ) {
            preDefinedClasses.push(
              full_property.allClasses[i][0] +
                "-" +
                full_property.allClasses[i][1]
            );
            full_property.allClasses.splice(i, 1);
          }
        }
        if (!isNaN(full_property.allClasses[i][1])) {
          // selecting all auto classes
          let temp_size = full_property.allClasses[i][1];
          checkPropertyName(i); // creating property name

          for (j in css_excludes) {
            // excluding css properties that don't get px values
            if (full_property.allClasses[i][0] != css_excludes[j]) {
              auto_size = `${temp_size}px`;
            } else {
              auto_size = temp_size;
            }
            // opacity range is from 0 to 1 and class names for it are opacity-0 to opacity-1000
            if (full_property.allClasses[i][0] == "opacity") {
              auto_size = temp_size / 1000;
            }
          }

          css_base(i, auto_size, xy_situation); // envoking css_base function
          xy_situation = "none"; // specifying xy situation
        } else {
          // selecting all custom classes
          checkPropertyName(i); // creating property name
          css_base(i, full_property.allClasses[i][1], xy_situation); // envoking css_base function
          xy_situation = "none"; // specifying xy situation
        }
      }
    }
    convertingClasses(); // envoking convertingClasses function

    // setting property name function
    function checkPropertyName(index) {
      let temp_class;
      let temp_className;
      pro_classes.developed.forEach((elem) => {
        if (full_property.allClasses[index][0].includes(elem)) {
          full_property.allClasses[index][0] = full_property.allClasses[
            index
          ][0].replace(elem, "");
          temp_class = index;
          temp_className = elem;
        }
      });

      for (j in css_shortcuts) {
        if (css_shortcuts[j][0] == full_property.allClasses[index][0]) {
          property_name = css_shortcuts[j][1];
          if (css_shortcuts[j].length == 3) {
            xy_situation = css_shortcuts[j][2];
          }
          if (temp_class == index) {
            full_property.allClasses[i][0] =
              temp_className + full_property.allClasses[i][0];
          }
        }
      }
    }

    let proClass = new Array(); // indexing every pro class position for preDefined classes

    // simplifying predefined classes for css_base function
    let preDefined_value = undefined;
    function convertingPreDefinedClasses() {
      for (index in preDefinedClasses) {
        pro_classes.developed.forEach((elem, i) => {
          if (preDefinedClasses[index].includes(elem)) {
            // saving pro classes positions
            pro_classes_index.preDefinedClasses.push(
              full_property.allClasses.length
            );
            // removing keywords from pro classes
            preDefinedClasses[index] = preDefinedClasses[index].replace(
              elem,
              ""
            );
            proClass.push(i);
          }
        });

        for (i in full_class_shortcuts) {
          if (full_class_shortcuts[i][0] == preDefinedClasses[index]) {
            property_name = full_class_shortcuts[i][1];
            preDefined_value = full_class_shortcuts[i][2];
            if (full_class_shortcuts[i].length == 4) {
              xy_situation = full_class_shortcuts[i][3];
            }
          }
          if (preDefined_value != undefined) {
            // simplifying only defined classes
            full_property.allClasses.push([
              preDefinedClasses[index],
              preDefined_value,
              "preDefined",
            ]);

            css_base(
              full_property.allClasses.length - 1,
              preDefined_value,
              xy_situation
            );

            preDefined_value = new String();
            xy_situation = "none"; // setting back to default values
            preDefined_value = undefined; // setting back to default values
          }
        }
      }
    }
    convertingPreDefinedClasses();

    // creating a single css node with the values
    function css_base(i, value, xy) {
      // fixing dark-mode classes for preDefined classes
      for (j in pro_classes_index.preDefinedClasses) {
        if (i == pro_classes_index.preDefinedClasses[j]) {
          full_property.allClasses[pro_classes_index.preDefinedClasses[j]][0] =
            pro_classes.developed[proClass[proClass.length - 1]] +
            full_property.allClasses[pro_classes_index.preDefinedClasses[j]][0];
        }
      }

      let temp_name;
      switch (full_property.allClasses[i][2]) {
        case "preDefined": // reseting pre defined classes format to /[a-z-Z]
          temp_name = full_property.allClasses[i][0];
          break;
        case "autoClass": // reseting auto classes format to /[a-z-Z]+-\d+/
          full_property.allClasses[i].pop();
          temp_name = full_property.allClasses[i].join("-");
          break;
        case "customClass": // reseting custom classes format to /[a-z-Z]+-\[/
          full_property.allClasses[i].pop();
          let temp_container = full_property.allClasses[i][1];
          full_property.allClasses[i].pop();
          full_property.allClasses[i].push("-[");
          full_property.allClasses[i].push(temp_container);
          full_property.allClasses[i].push("]");
          temp_name = full_property.allClasses[i].join("");
          break;
      }

      pro_classes.developed.forEach((elem) => {
        if (temp_name.includes(elem)) {
          // adding !important to pro classes
          if (!value.includes("_!important")) {
            value += "_!important";
          }
        }
      });

      // correcting "_", "%", "#", "(", ")", "[", "]" and ":" operators for css errors
      value = value.replace(/_/g, " ");
      temp_name = temp_name.replace(/%/g, "\\%");
      temp_name = temp_name.replace(/\*/g, "\\*");
      temp_name = temp_name.replace(/\//g, "\\/");
      temp_name = temp_name.replace(/\+/g, "\\+");
      temp_name = temp_name.replace(/#/g, "\\#");
      temp_name = temp_name.replace(/\)/g, "\\)");
      temp_name = temp_name.replace(/\(/g, "\\(");
      temp_name = temp_name.replace(/\[/g, "\\[");
      temp_name = temp_name.replace(/]/g, "\\]");
      temp_name = temp_name.replace(/:/g, "\\:");
      temp_name = temp_name.replace(/\$/g, "\\$");
      temp_name = temp_name.replace(/\./g, "\\.");

      if (temp_name.includes("hover\\:")) {
        // adding hover pseudo
        temp_name += ":hover";
      }

      // using css variables using $
      if (temp_name.includes("$")) {
        value = value.replace("$", "var(--");
        value += ")";
      }

      switch (
        xy // changing output css for differnet xy_situation values
      ) {
        case "horizontal":
          pushToCSS("left");
          pushToCSS("right");
          break;
        case "vertical":
          pushToCSS("top");
          pushToCSS("bottom");
          break;
        case "none":
          css.push(`\n.${temp_name} {\n\t${property_name}: ${value};\n}\n`);
          break;
      }

      function pushToCSS(xoy) {
        css.push(
          `\n.${temp_name} {\n\t${property_name}-${xoy}: ${value};\n}\n`
        );
      }
    }

    // writing the css nodes into the main.css file
    function wrtieInCSS(output) {
      const cssContent = css.join("");

      // Write the CSS content to the main.css file
      fs.writeFile(cssURL, cssContent, "utf8", (err) => {
        if (err) {
          console.error(err);
        } else {
          if (output) {
            console.log(`CSS updated successfully!`);
          }
        }
      });
    }
    wrtieInCSS(false);
    wrtieInCSS(false);
    wrtieInCSS(true);
  }
});
